import torch
from PIL import Image
import io
import os
import base64
from flask import Flask, Response, request, abort
import shutil
import os
model = torch.hub.load('yolov5', 'custom', path='best.pt', source='local')

app = Flask(__name__)

@app.route("/")
def home():
    return Response("Weed detection api home")

@app.route("/detect", methods=['POST', 'GET'])
def detect():
    if request.method == "GET":
        return {"status":201}

    if not request.json or 'image' not in request.json: 
        abort(400)

    # get the base64 encoded string
    im_b64 = request.json['image']
    img = Image.open(io.BytesIO(base64.decodebytes(bytes(im_b64, "utf-8"))))
    results = model([img], size=640)
    if os.path.exists('runs/detect'):
        shutil.rmtree('runs')
   
    results.save()
    
    #os.path.abspath('app.py')
    filename = 'runs/detect/exp/image0.jpg'

    with open(filename, "rb") as img:
        string = base64.b64encode(img.read()).decode('utf-8')
    return {'image':string}
 
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

