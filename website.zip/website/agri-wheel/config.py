class Config:
    weather_api = ""
    crop_recommend = ""
    sensor_data_api = ""
    database = "DefaultEndpointsProtocol=https;AccountName=datafromfpga;AccountKey=g1Z9bLD4RZZKKeLGoZYKGRFHxM7zlqmUscB5W40wdYg5PuL0sxX1GlxxrVJSdCNIQSs/qFasHY+mNDCuEG3XVQ==;EndpointSuffix=core.windows.net"
    


config = Config()